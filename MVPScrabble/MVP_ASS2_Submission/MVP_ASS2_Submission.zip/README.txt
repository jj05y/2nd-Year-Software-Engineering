Team MVP - Assignment 2 Submission Contents

NOTE: There are a lot of classes that are extra work that the team has
      put into this project. The classes specific to this submission are
      in ./src/Ass2/

src/ - contains the full project as it stands at the minute

Ass2ClassDiagram.png - A UML diagram of the classes only in the assignment 2 package
ProjectClassDiagram.png - A UML diagram of the entire project
Assignment2ScrumNotes.pdf - scrum notes from this sprint

BoardExample.jar - an executable file demoing the boards functionality
BoardExampleExampleOutput.txt - the output from BoardExample.jar

BoardTest.jar - an executable file testing the boards functionality
BoardTestExampleOutput.txt - the output from BoardTest.jar

README.txt - this




 