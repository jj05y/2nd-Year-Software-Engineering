package Ass4;

import java.util.ArrayList;


public class Searcher {

	ArrayList<String> wL;
	String lF; //looking for
	
	public Searcher(ArrayList<String> l) {
		wL = l;

		
	}
	
	public int find(String s) {
		lF = s;
		//char[] chars = s.toCharArray();
		//Arrays.sort(chars);
		//lF = new String(chars);
		return search(0, wL.size()-1);
	}
	
	private int search(int l, int u) {
		
		if (l > u) {
			return  -1;
		}

		int m = (l+u)/2;
		
		if (lF.compareTo(wL.get(m)) < 0) {
			return search(l, m-1);
		} else if ((lF.compareTo(wL.get(m)) > 0)) {
			return search(m+1, u);
		} else {
			return m;
		}
		
	}

}
