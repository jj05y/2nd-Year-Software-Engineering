/*
 * Edwin Keville
 * Assignment One, 
 * Frame.java
 */

package Ass1;

import java.util.ArrayList;

import Ass2.Consts;

public class Frame {

	private int maxTileinFrame;
	private ArrayList<Tile> frame;
	private Pool pool;

	/**
	 * @param pool - frame is filled with tiles from pool
	 */
	public Frame(Pool p) {
		maxTileinFrame = Consts.FRAME_SIZE;
		frame = new ArrayList<Tile>();
		pool = p;
		fillFrame();

	}

	/**
	 * 
	 * @param pool - fills frame from pool
	 * @return 0 - returns -1 if pool is empty and cannot fully fill
	 * 
	 */
	public int fillFrame() {
		while (frame.size() < maxTileinFrame) {
			if (pool.isEmpty()) {
				return Consts.POOL_EMPTY;
			}
			frame.add(pool.getRandTile());
		}
		return Consts.SUCCESS;
	}

	/**
	 * 
	 * @return - returns true if frame is empty. false if anything else.
	 */
	public boolean isEmpty() {
		return !(frame.size() > Consts.ZERO);
	}

	/**
	 * 
	 * @return - returns contents of the frame as a string.
	 */
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < frame.size(); i++) {
			sb.append("|" + frame.get(i).getLetter() + " " + frame.get(i).getScore() + "|");
		}
		return new String(sb + "\n");
	}

	/**
	 * 
	 * @param i - index of tile to remove
	 * @return returns the removed tile.
	 */
	public Tile removeTile(int i) {
		return frame.remove(i);
	}

	/**
	 * returns all current tiles to the pool and fills a new frame.
	 */
	public void renewFrame() {
		while (!frame.isEmpty()) {
			pool.getTiles().add(frame.remove(0));

		}
		fillFrame();
	}

	/**
	 * 
	 * @return - returns this frame
	 */
	public Frame getFrame() {
		return this;
	}

	public ArrayList<Tile> getTiles() {
		return frame;
	}

	/**
	 * takes letter from the user and searches for it in the frame
	 * 
	 * @param c
	 * @return - true returns index of letter. or will return false
	 */
	public int letterSearch(char c) {
		for (int i = 0; i < frame.size(); i++) {
			if (c == frame.get(i).getLetter()) {
				return i;
			}
		}
		return Consts.NOT_FOUND;
	}

	/**
	 * @return - returns current quantity of tiles
	 */
	public int getCurrentFrameSize() {
		return frame.size();
	}

	/**
	 * .
	 * 
	 * @param word - lets user know if the word they are choosing is playable
	 *            from their frame
	 * @return array list - returns if word is there. null if not
	 */
	public ArrayList<Tile> checkFrameForWord(String word) {
		ArrayList<Tile> tempFrame = new ArrayList<Tile>();
		boolean isFound;
		for (int i = 0; i < word.length(); i++) {
			isFound = false;
			for (int j = 0; j < frame.size(); j++) {
				if (word.charAt(i) == frame.get(j).getLetter()) {
					tempFrame.add(frame.remove(j));
					isFound = true;
					break;
				}
			}
			if (!isFound) {
				for (int k = 0; k < frame.size(); k++) {
					if (frame.get(k).getLetter() == '_') {
						tempFrame.add(frame.remove(k));
						isFound = true;
						break;
					}
				}

			}

		}

		if (tempFrame.size() == word.length()) {
			fillFrame();
			return tempFrame;
		} else {
			int tempFrameSize = tempFrame.size();
			for (int i = 0; i < tempFrameSize; i++) {
				frame.add(tempFrame.remove(0));
			}
			return Consts.WORD_NOT_IN_FRAME;
		}
	}

	/**
	 * testing frame. will use particular word to test pool and frame usage.
	 * 
	 * @param word
	 */
	public void buildTestFrame(String word) {
		if (word.length() > Consts.FRAME_SIZE) {
			System.out
					.println("***ERROR! Word your are trying to put into your frame is not possible***\n***unexpected results will follow, run again***");
		}
		frame.clear();
		for (int i = 0; i < word.length(); i++) {
			for (int j = 0; j < pool.getNumTiles(); j++) {
				if (word.charAt(i) == pool.getSpecificTile(j).getLetter()) {
					frame.add(pool.removeSpecificTile(j));
					break;
				}
			}
		}
		if (frame.size() != word.length()) {
			System.out
					.println("***ERROR! Word your are trying to put into your frame is not possible***\n***unexpected results will follow, run again***");
		}
		fillFrame();
	}

}
