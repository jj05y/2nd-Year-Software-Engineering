/*
 * Joe Duffin
 * Assignment One, 
 * Pool.java
 */
package Ass1;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class Tile {

	private int score;
	private char letter;
	private JLabel label;
	private ImageIcon img;

	/**
	 * @param s - the score value of this tile
	 * @param l - the letter value of this tile
	 */
	public Tile(int s, char l) {
		score = s;
		letter = l;
		label = new JLabel();
		label.setSize(40, 40);
		if (letter != '[') {
			img = new ImageIcon(getClass().getResource("/GUI/pics/" + new Character(letter).toString().toLowerCase() + ".png"));
		} else {
			img = new ImageIcon(getClass().getResource("/GUI/pics/blank.png"));
		}
		label.setIcon(img);
	}

	/**
	 * @return the score value of this tile is returned
	 */
	public int getScore() {
		return score;
	}

	/**
	 * @param score - the value to set the tiles score with
	 */
	public void setScore(int score) {
		this.score = score;
	}

	/**
	 * @return - returns the letter value of this tile
	 */
	public char getLetter() {
		return letter;
	}

	/**
	 * @param letter - the letter to
	 */
	public void setLetter(char letter) {
		this.letter = letter;
	}

	/**
	 * @return - returns a string representation of this tile
	 */
	public String toString() {
		return new String("Letter: " + letter + "\tScore: " + score);
	}
	
	public JLabel getLabel(){
		return label;
		
	}

}
