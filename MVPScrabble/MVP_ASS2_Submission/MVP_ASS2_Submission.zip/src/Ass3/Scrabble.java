package Ass3;

public class Scrabble {

}
