package Ass2;

import java.util.ArrayList;

import Ass1.*;
import Ass4.*;

public class Board {

	private Square[][] board;
	private Searcher searcher;

	/**
	 *  Initializes a bland board and allocates score multipliers and characters to special squares
	 *  Also instantiates a searcher to search the dictionary
	 */
	public Board() {
		board = new Square[Consts.BOARD_SIZE][Consts.BOARD_SIZE];
		for (int row = 0; row < board.length; row++) {
			for (int col = 0; col < board[0].length; col++) {
				board[row][col] = new Square();
			}
		}
		setUpSquares();
		searcher = new Searcher((new DictionaryMaker().getDictionary()));

	}

	/**
	 * @param word
	 * @param i - the row index of the start of the word
	 * @param j - the column index of the start of the word
	 * @param dir - the direction of the word to be played
	 * @param p - player playing the word
	 * @return - returns the score for the played word or appropriate error
	 */
	public int go(String word, int i, int j, int dir, Player p) {

		ArrayList<Tile> wordTiles;
		String newWord;
		if (searcher.find(word) != -1) {
			if ((newWord = checkForMove(word, i, j, dir)) != null) {
				if ((wordTiles = p.getFrame().checkFrameForWord(newWord)) != null) {
					placeWord(wordTiles, i, j, dir);
					return computeScore(i, j, dir);
				} else {
					return Consts.NOT_IN_FRAME;
				}
			} else {
				return Consts.MOVE_NOT_POSSIBLE;
			}
		} else {
			return Consts.NOT_IN_DICTIONARY;
		}
	}

	/**
	 * Currently this only returns the score of the word played, not score
	 * of words created, eg, adjacent words
	 * 
	 * @param i - the row index of the start of the word
	 * @param j - the column index of the start of the word
	 * @param dir - direction that word is going
	 * @return - returns the score yielded by the word
	 */
	private int computeScore(int i, int j, int dir) {

		int score = Consts.ZERO;
		int wordMult = Consts.ONE;


		while (board[i][j].getTile() != null) {
			score += board[i][j].getTile().getScore() * board[i][j].getLetterMultiplier();
			wordMult *= board[i][j].getWordMultiplier();
			board[i][j].setLetterMultiplier(1);
			board[i][j].setWordMultiplier(1);
			if (dir == Consts.DOWN) {
				i++;
			} else {
				j++;
			}
		}
		return score * wordMult;
	}

	/**
	 * @param word - the word attempted to be played
	 * @param startI - the row index of the start of the word
	 * @param startJ - the column index of the start of the word
	 * @param dir - direction that word is going
	 * @return
	 */
	private String checkForMove(String word, int startI, int startJ, int dir) {

		StringBuilder sb = new StringBuilder();
		boolean golden = false;

		int i = startI, j = startJ;
		for (int k = 0; k < word.length(); k++) {
			if (i > 14 || i < 0 || j > 14 || j < 0) {
				return Consts.OUT_OF_BOUNDS;
			}
			if (board[i][j].getTile() != null) {
				golden = true;
			} else if (i == 7 && j == 7 || isThereAnAdjacant(i, j)) {
				golden = true;
				sb.append(word.charAt(k));
			} else {
				sb.append(word.charAt(k));
			}

			if (dir == Consts.DOWN) {
				i++;
			} else {
				j++;
			}

		}

		i = startI;
		j = startJ;
		for (int k = 0; k < word.length(); k++) {
			if (board[i][j].getTile() != null) {
				if (board[i][j].getTile().getLetter() != word.charAt(k)) {
					golden = false;
				}
			}
			if (dir == Consts.DOWN) {
				i++;
			} else {
				j++;
			}
		}

		if (!golden) {
			return null;
		} else {
			// System.out.println(sb);
			return new String(sb);
		}

	}

	/**
	 * @param i - the i index of the tile being checked
	 * @param j - the j index of the tile being checked
	 * @return - returns true if there is an adjacent tile, false otherwise
	 */
	private boolean isThereAnAdjacant(int i, int j) {

		int[][] moves = { { -1, 1, 1, -1, 0 }, { 0, 1, -1, -1, 1 } };

		for (int k = 0; k < moves[0].length; k++) {

			i += moves[0][k];
			j += moves[1][k];

			if (i <= 14 && i >= 0 && j <= 14 && j >= 0) {
				if (board[i][j].getTile() != null) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Resets the board to initial state
	 */
	public void reset() {
		for (int row = 0; row < board.length; row++) {
			for (int col = 0; col < board[0].length; col++) {
				board[row][col].setDisplayChar(Consts.BLANK_SQUARE);
				board[row][col].setTile(null);
			}
		}
		setUpSquares();
	}

	/**
	 * @param wordTiles - An array list of tiles to be put on the board
	 * @param i - the i index of the start of the word
	 * @param j - the j index of the start of the word
	 * @param dir - the direction the word is going
	 */
	public void placeWord(ArrayList<Tile> wordTiles, int i, int j, int dir) {

		for (int k = 0; k < wordTiles.size(); k++) {
			if (board[i][j].getTile() == null) {
				board[i][j].setTile(wordTiles.get(k));
			} else {
				k--;
			}
			// System.out.println(board[i][j].getTile().getLetter());
			if (dir == Consts.DOWN) {
				i++;
			} else {
				j++;
			}
		}
	}

	/**
	 * @return - returns a String representation of the board
	 */
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for (int row = 0; row < board.length; row++) {
			if (row == 0) {
				sb.append(" ----------------------------------------------------------- \n");
			} else {
				sb.append("|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|\n");
			}

			for (int col = 0; col < board[0].length; col++) {
				sb.append("|");
				if (board[row][col].getTile() == null) {

					sb.append(board[row][col].getDisplayChar());
				} else {
					sb.append("[" + board[row][col].getTile().getLetter() + "]");
				}

			}
			sb.append("|");
			sb.append('\n');
		}

		sb.append(" ----------------------------------------------------------- \n");

		return new String(sb);

	}
	
	/**
	 * @return - the 2D array of squares is returned.
	 */
	public Square[][] getSquares() {
		return board;
	}

	/**
	 * Initializes the special squares
	 */
	private void setUpSquares() {
		board[0][0].setWordMultiplier(Consts.TRIPLE);
		board[0][0].setDisplayChar(Consts.TRIPLE_WORD);
		board[0][7].setWordMultiplier(Consts.TRIPLE);
		board[0][7].setDisplayChar(Consts.TRIPLE_WORD);
		board[0][14].setWordMultiplier(Consts.TRIPLE);
		board[0][14].setDisplayChar(Consts.TRIPLE_WORD);
		board[7][0].setWordMultiplier(Consts.TRIPLE);
		board[7][0].setDisplayChar(Consts.TRIPLE_WORD);
		board[7][14].setWordMultiplier(Consts.TRIPLE);
		board[7][14].setDisplayChar(Consts.TRIPLE_WORD);
		board[14][0].setWordMultiplier(Consts.TRIPLE);
		board[14][0].setDisplayChar(Consts.TRIPLE_WORD);
		board[14][7].setWordMultiplier(Consts.TRIPLE);
		board[14][7].setDisplayChar(Consts.TRIPLE_WORD);
		board[14][14].setWordMultiplier(Consts.TRIPLE);
		board[14][14].setDisplayChar(Consts.TRIPLE_WORD);

		board[1][1].setWordMultiplier(Consts.DOUBLE);
		board[1][1].setDisplayChar(Consts.DOUBLE_WORD);
		board[1][13].setWordMultiplier(Consts.DOUBLE);
		board[1][13].setDisplayChar(Consts.DOUBLE_WORD);
		board[2][2].setWordMultiplier(Consts.DOUBLE);
		board[2][2].setDisplayChar(Consts.DOUBLE_WORD);
		board[2][12].setWordMultiplier(Consts.DOUBLE);
		board[2][12].setDisplayChar(Consts.DOUBLE_WORD);
		board[3][3].setWordMultiplier(Consts.DOUBLE);
		board[3][3].setDisplayChar(Consts.DOUBLE_WORD);
		board[3][11].setWordMultiplier(Consts.DOUBLE);
		board[3][11].setDisplayChar(Consts.DOUBLE_WORD);
		board[4][4].setWordMultiplier(Consts.DOUBLE);
		board[4][4].setDisplayChar(Consts.DOUBLE_WORD);
		board[4][10].setWordMultiplier(Consts.DOUBLE);
		board[4][10].setDisplayChar(Consts.DOUBLE_WORD);
		board[7][7].setWordMultiplier(Consts.DOUBLE);
		board[7][7].setDisplayChar(Consts.STAR);
		board[10][4].setWordMultiplier(Consts.DOUBLE);
		board[10][4].setDisplayChar(Consts.DOUBLE_WORD);
		board[10][10].setWordMultiplier(Consts.DOUBLE);
		board[10][10].setDisplayChar(Consts.DOUBLE_WORD);
		board[11][3].setWordMultiplier(Consts.DOUBLE);
		board[11][3].setDisplayChar(Consts.DOUBLE_WORD);
		board[11][11].setWordMultiplier(Consts.DOUBLE);
		board[11][11].setDisplayChar(Consts.DOUBLE_WORD);
		board[12][2].setWordMultiplier(Consts.DOUBLE);
		board[12][2].setDisplayChar(Consts.DOUBLE_WORD);
		board[12][12].setWordMultiplier(Consts.DOUBLE);
		board[12][12].setDisplayChar(Consts.DOUBLE_WORD);
		board[13][1].setWordMultiplier(Consts.DOUBLE);
		board[13][1].setDisplayChar(Consts.DOUBLE_WORD);
		board[13][13].setWordMultiplier(Consts.DOUBLE);
		board[13][13].setDisplayChar(Consts.DOUBLE_WORD);

		board[1][5].setLetterMultiplier(Consts.TRIPLE);
		board[1][5].setDisplayChar(Consts.TRIPLE_LETTER);
		board[1][9].setLetterMultiplier(Consts.TRIPLE);
		board[1][9].setDisplayChar(Consts.TRIPLE_LETTER);
		board[5][1].setLetterMultiplier(Consts.TRIPLE);
		board[5][1].setDisplayChar(Consts.TRIPLE_LETTER);
		board[5][5].setLetterMultiplier(Consts.TRIPLE);
		board[5][5].setDisplayChar(Consts.TRIPLE_LETTER);
		board[5][9].setLetterMultiplier(Consts.TRIPLE);
		board[5][9].setDisplayChar(Consts.TRIPLE_LETTER);
		board[5][13].setLetterMultiplier(Consts.TRIPLE);
		board[5][13].setDisplayChar(Consts.TRIPLE_LETTER);
		board[9][1].setLetterMultiplier(Consts.TRIPLE);
		board[9][1].setDisplayChar(Consts.TRIPLE_LETTER);
		board[9][5].setLetterMultiplier(Consts.TRIPLE);
		board[9][5].setDisplayChar(Consts.TRIPLE_LETTER);
		board[9][9].setLetterMultiplier(Consts.TRIPLE);
		board[9][9].setDisplayChar(Consts.TRIPLE_LETTER);
		board[9][13].setLetterMultiplier(Consts.TRIPLE);
		board[9][13].setDisplayChar(Consts.TRIPLE_LETTER);
		board[13][5].setLetterMultiplier(Consts.TRIPLE);
		board[13][5].setDisplayChar(Consts.TRIPLE_LETTER);
		board[13][9].setLetterMultiplier(Consts.TRIPLE);
		board[13][9].setDisplayChar(Consts.TRIPLE_LETTER);

		board[0][3].setLetterMultiplier(Consts.DOUBLE);
		board[0][3].setDisplayChar(Consts.DOUBLE_LETTER);
		board[0][11].setLetterMultiplier(Consts.DOUBLE);
		board[0][11].setDisplayChar(Consts.DOUBLE_LETTER);
		board[2][6].setLetterMultiplier(Consts.DOUBLE);
		board[2][6].setDisplayChar(Consts.DOUBLE_LETTER);
		board[2][8].setLetterMultiplier(Consts.DOUBLE);
		board[2][8].setDisplayChar(Consts.DOUBLE_LETTER);
		board[3][0].setLetterMultiplier(Consts.DOUBLE);
		board[3][0].setDisplayChar(Consts.DOUBLE_LETTER);
		board[3][7].setLetterMultiplier(Consts.DOUBLE);
		board[3][7].setDisplayChar(Consts.DOUBLE_LETTER);
		board[3][14].setLetterMultiplier(Consts.DOUBLE);
		board[3][14].setDisplayChar(Consts.DOUBLE_LETTER);
		board[6][2].setLetterMultiplier(Consts.DOUBLE);
		board[6][2].setDisplayChar(Consts.DOUBLE_LETTER);
		board[6][6].setLetterMultiplier(Consts.DOUBLE);
		board[6][6].setDisplayChar(Consts.DOUBLE_LETTER);
		board[6][8].setLetterMultiplier(Consts.DOUBLE);
		board[6][8].setDisplayChar(Consts.DOUBLE_LETTER);
		board[6][12].setLetterMultiplier(Consts.DOUBLE);
		board[6][12].setDisplayChar(Consts.DOUBLE_LETTER);
		board[7][3].setLetterMultiplier(Consts.DOUBLE);
		board[7][3].setDisplayChar(Consts.DOUBLE_LETTER);
		board[7][11].setLetterMultiplier(Consts.DOUBLE);
		board[7][11].setDisplayChar(Consts.DOUBLE_LETTER);
		board[8][2].setLetterMultiplier(Consts.DOUBLE);
		board[8][2].setDisplayChar(Consts.DOUBLE_LETTER);
		board[8][6].setLetterMultiplier(Consts.DOUBLE);
		board[8][6].setDisplayChar(Consts.DOUBLE_LETTER);
		board[8][8].setLetterMultiplier(Consts.DOUBLE);
		board[8][8].setDisplayChar(Consts.DOUBLE_LETTER);
		board[8][12].setLetterMultiplier(Consts.DOUBLE);
		board[8][12].setDisplayChar(Consts.DOUBLE_LETTER);
		board[11][0].setLetterMultiplier(Consts.DOUBLE);
		board[11][0].setDisplayChar(Consts.DOUBLE_LETTER);
		board[11][7].setLetterMultiplier(Consts.DOUBLE);
		board[11][7].setDisplayChar(Consts.DOUBLE_LETTER);
		board[11][14].setLetterMultiplier(Consts.DOUBLE);
		board[11][14].setDisplayChar(Consts.DOUBLE_LETTER);
		board[12][6].setLetterMultiplier(Consts.DOUBLE);
		board[12][6].setDisplayChar(Consts.DOUBLE_LETTER);
		board[12][8].setLetterMultiplier(Consts.DOUBLE);
		board[12][8].setDisplayChar(Consts.DOUBLE_LETTER);
		board[14][3].setLetterMultiplier(Consts.DOUBLE);
		board[14][3].setDisplayChar(Consts.DOUBLE_LETTER);
		board[14][11].setLetterMultiplier(Consts.DOUBLE);
		board[14][11].setDisplayChar(Consts.DOUBLE_LETTER);
	}
	
	/*trying out new method.. may delete after*/
	public Square getSquare(int row, int column) {
		return board[row][column];
	}

}
