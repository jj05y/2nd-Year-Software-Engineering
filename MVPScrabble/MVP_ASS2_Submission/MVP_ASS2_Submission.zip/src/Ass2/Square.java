package Ass2;

import Ass1.Tile;

public class Square {
	
	private Tile tile;
	private int letterMultiplier;
	private int wordMulti;
	private String displayChar; //needs to be a string for the white space
	//hi gerard displayChar added to the toString IF tile is null
	
	/**
	 * Initializes every thing to a default value
	 */
	public Square() {
		tile = null;
		letterMultiplier = Consts.SINGLE;
		wordMulti = Consts.SINGLE;
		displayChar = Consts.BLANK_SQUARE;
	}

	/*
	 * GETTERS AND SETTERS 
	 */
	public Tile getTile() {
		return tile;
	}

	public void setTile(Tile t) {
		this.tile = t;
	}

	public int getLetterMultiplier() {
		return letterMultiplier;
	}

	public void setLetterMultiplier(int letterMultiplier) {
		this.letterMultiplier = letterMultiplier;
	}
	
	public int getWordMultiplier() {
		return wordMulti;
	}

	public void setWordMultiplier(int wordMulti) {
		this.wordMulti = wordMulti;
	}
	public String getDisplayChar() {
		return displayChar;
	}

	public void setDisplayChar(String displayChar) {
		this.displayChar = displayChar;
	}
	
	
}
