package Ass2;

import java.util.ArrayList;

import Ass1.Tile;

public final class Consts {
	public static final int BOARD_SIZE = 15; 
	public static final int FRAME_SIZE = 7;
	
	public static final int TRIPLE = 3;
	public static final int DOUBLE = 2;
	public static final int SINGLE = 1;
	
	public static final int ONE = 1;
	public static final int ZERO = 0;
	
	public static final int POOL_EMPTY = -1;
	public static final int NOT_FOUND = -1;
	public static final int SUCCESS = 0;
	
	public static final int NOT_IN_DICTIONARY = -3;
	public static final int MOVE_NOT_POSSIBLE = -1;
	public static final int NOT_IN_FRAME = -2;
	
	public static final int ACROSS = 1;
	public static final int DOWN = 0;
	
	public static final char A = 'A';
	
	public static final String BLANK_SQUARE = "   ";
	public static final String DOUBLE_WORD = "d_w";
	public static final String DOUBLE_LETTER = "d_l";
	public static final String TRIPLE_WORD = "t_w";
	public static final String TRIPLE_LETTER = "t_l";
	public static final String STAR = " * ";
	public static final String DICTIONARY_FILE = "sowpods";
	
	public static final String OUT_OF_BOUNDS = null;
	public static final ArrayList<Tile> WORD_NOT_IN_FRAME = null;

	
	

	
}
