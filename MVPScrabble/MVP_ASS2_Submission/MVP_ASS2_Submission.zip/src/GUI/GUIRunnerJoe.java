package GUI;

import Ass1.Frame;
import Ass1.Player;
import Ass1.Pool;
import Ass2.Board;

public class GUIRunnerJoe {
	public static void main (String[] args) {
		@SuppressWarnings("unused")
		BoardDrawerJoe bd = new BoardDrawerJoe(new Board().getSquares(), new Player("Bob", new Frame(new Pool())));
	}

}
