Assigment 4

MVP Submission

NOTES :
  For testing this assigment there is the option to use file input instead of user input.
  This allows us to force certain conditions and run scripted games.
  In the Ass3 package there are alot of test scripts, all of which have been used for 
  testing in ChallengeTester.java and LastTurnTester.java
  
Contents: 
  src/ - the entire source code is here, with the classes relating to this assigment in 
	the Ass3 package and Ass4 package.
	Ass3:
	  - The 'challenge' option has been added to ass3/UI.java (line 157)
	  - The challenge and undo last turn methods have been added to ass3.Scrabble.java
						      (lines 471 and 491 respectively)
	  - A LastTurn inner class has also been added to ass3/Scrabble.java (line 531)
	    This class holds all relavent info needed to 'undo' a turn
	Ass4:
	  - The ass4 package contains new classes which load, read and query the dictionary
	    aswell as some test classes


  LastTurnTesterExampleOutput.txt - Demostrates a scripted game and at the end
				    the information about the last played turn is output.
  LastTurnTester.jar - Example output from above jar file

  ChallengeTester.jar - Demonstrates a scripted game where a turn is challenged
  ChallengeTesterExampleOutput.txt - Example output from above jar file

  ScrabbleRunner.jar
  ChallengingNonScriptedExampleOuput.txt - An output from playing a game with the 
					   above jar file

  Assignment4ScrumNotes.pdf - Scrum Notes from this sprint

  Assigment3ClassDiagram.png - UML Diagram of classes in the Ass3 Package
  Assigment4ClassDiagram.png - UML Diagram of classes in the Ass4 Package
  EntireProjectDiagram.png   - UML Diagram of the entire project

  README.txt - this