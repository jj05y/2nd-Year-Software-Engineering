package Ass3;

/**
 * This class has a main function to instantiate the user interface and start it.
 * @author MVP
 *
 */
public class SrabbleRunner {
	public static void main (String[] args) {
		UI ui = new UI();
		ui.start();
	}	

}
