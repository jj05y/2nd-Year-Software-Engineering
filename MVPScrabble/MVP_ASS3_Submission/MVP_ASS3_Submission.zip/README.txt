Assigment 3

MVP Submission

NOTES:
  For testing this assigment there is the option to use file input instead of user input.
  This allows us to force certain conditions and run scripted games.
  In the Ass3 package there are alot of test scripts, all of which have been used for 
  testing in UITester.java and UIBoundsTester.java
  

src/ - the entire source code is here, with the classes relating to this assigment in 
       the Ass3 package.

UITesterExampleOutPut.txt - Contains the following tests

			  MANUAL INSPECTION TESTS
			  - Parsing Correct Input
			  - Parsing Incorrect Input
			  - Parsing Help, Pass, Renew, Quit

			  AUTOMATED TESTS
			  - Conventional Scoring
			  - Adjacent Word Scoring
			  - Suffix Scoring
			  - Prefix Scoring

UIBoundsExampleOutPut 	- This file contains a test output of players playing words to 
			  The extremities of the board, Looking for array out of bounds 
			  errors.

NonScriptedGameExample 	- This file contains an actual game, as played by users. (finished 
			  prematurely).

ScrabbleRunner.jar     	 - The runnable Game
UITester.jar	      	 - The UITester executable
UIBountsTester.jar	 - The UIBoundsExampleOutPut executable

Assigment3ClassDiagram.png - UML Diagram of classes in the Ass3 Package
EntireProjectDiagram.png   - UML Diagram of the entire project

README.txt - this