package Ass4;

import java.util.ArrayList;

public class DictionaryMaker {

	private ArrayList<String> dictionary;
	@SuppressWarnings("unused")
	private Thread myThread;

	public DictionaryMaker() {
		dictionary = new ArrayList<String>();
		myThread = new Thread(new ThreadedFileReader(dictionary), "myThread");

		

	}

	public ArrayList<String> getDictionary() {
		return dictionary;
	}

	public void SetDictionary(ArrayList<String> d) {
		dictionary = d;
	}

}
